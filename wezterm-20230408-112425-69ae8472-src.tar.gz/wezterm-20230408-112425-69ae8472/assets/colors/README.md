This directory holds a copy of the wezterm color schemes from
the https://github.com/mbadolato/iTerm2-Color-Schemes/
repository.
